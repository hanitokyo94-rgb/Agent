import { useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetMe,
  useCompleteOnboarding,
  useUpdateProfile,
  useUploadAvatar,
  getGetMeQueryKey,
} from "@workspace/api-client-react";
import { Logo } from "@/components/Logo";

const SKILL_OPTIONS = [
  { value: "expert", label: "Expert", desc: "I build software professionally" },
  { value: "intermediate", label: "Intermediate", desc: "I know the basics" },
  { value: "beginner", label: "Beginner", desc: "Just getting started" },
];

const CATEGORY_OPTIONS = [
  "Commerce", "Design", "Marketing", "Technology", "Education", "Health", "Finance", "Other",
];

const AD_SOURCES = [
  "Twitter / X", "LinkedIn", "Google", "YouTube", "Friend / Word of mouth", "Other",
];

export function Onboarding() {
  const [step, setStep] = useState(0);
  const [skillLevel, setSkillLevel] = useState("");
  const [category, setCategory] = useState("");
  const [adSource, setAdSource] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const completeOnboarding = useCompleteOnboarding();
  const updateProfile = useUpdateProfile();
  const uploadAvatar = useUploadAvatar();

  function handleAvatarChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setAvatarFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setAvatarPreview(reader.result as string);
    reader.readAsDataURL(file);
  }

  async function handleFinish(skip = false) {
    await completeOnboarding.mutateAsync({ data: { skillLevel: skillLevel as "expert" | "intermediate" | "beginner", category, adSource } });

    if (!skip) {
      if (avatarFile) {
        const formData = new FormData();
        formData.append("file", avatarFile);
        await uploadAvatar.mutateAsync({ data: formData as any });
      }
      if (displayName && displayName !== user?.name) {
        await updateProfile.mutateAsync({ data: { name: displayName } });
      }
    }

    await queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    setLocation("/dashboard");
  }

  const steps = [
    // Step 0: Skill level
    <div key="skill" className="flex flex-col gap-4">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">Your experience level</h2>
        <p className="text-muted-foreground text-sm">This helps us personalize your experience</p>
      </div>
      <div className="flex flex-col gap-2.5 mt-2">
        {SKILL_OPTIONS.map((opt) => (
          <button
            key={opt.value}
            data-testid={`skill-${opt.value}`}
            onClick={() => { setSkillLevel(opt.value); setStep(1); }}
            className={`w-full text-left px-4 py-3.5 rounded-xl border transition-all ${
              skillLevel === opt.value
                ? "border-foreground bg-foreground/5"
                : "border-border hover:border-foreground/40"
            }`}
          >
            <div className="font-medium text-sm text-foreground">{opt.label}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{opt.desc}</div>
          </button>
        ))}
      </div>
    </div>,

    // Step 1: Category
    <div key="category" className="flex flex-col gap-4">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">What's your focus?</h2>
        <p className="text-muted-foreground text-sm">Select the domain you're most interested in</p>
      </div>
      <div className="grid grid-cols-2 gap-2.5 mt-2">
        {CATEGORY_OPTIONS.map((cat) => (
          <button
            key={cat}
            data-testid={`category-${cat}`}
            onClick={() => { setCategory(cat); setStep(2); }}
            className={`px-4 py-3.5 rounded-xl border text-sm font-medium transition-all ${
              category === cat
                ? "border-foreground bg-foreground text-background"
                : "border-border hover:border-foreground/40 text-foreground"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>
    </div>,

    // Step 2: Ad source
    <div key="source" className="flex flex-col gap-4">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">How did you find us?</h2>
        <p className="text-muted-foreground text-sm">Help us understand how you heard about Stealth</p>
      </div>
      <div className="flex flex-col gap-2.5 mt-2">
        {AD_SOURCES.map((src) => (
          <button
            key={src}
            data-testid={`source-${src}`}
            onClick={() => { setAdSource(src); setStep(3); }}
            className={`w-full text-left px-4 py-3 rounded-xl border text-sm font-medium transition-all ${
              adSource === src
                ? "border-foreground bg-foreground/5"
                : "border-border hover:border-foreground/40"
            }`}
          >
            {src}
          </button>
        ))}
      </div>
    </div>,

    // Step 3: Profile setup
    <div key="profile" className="flex flex-col gap-4">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-1">Set up your profile</h2>
        <p className="text-muted-foreground text-sm">Optional — you can always change this later</p>
      </div>

      {/* Avatar */}
      <div className="flex flex-col items-center gap-3 mt-2">
        <label htmlFor="avatar-upload" className="cursor-pointer">
          <div className="w-20 h-20 rounded-full border-2 border-dashed border-border overflow-hidden flex items-center justify-center bg-muted hover:border-primary/50 transition-colors">
            {avatarPreview ? (
              <img src={avatarPreview} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="text-2xl font-bold text-muted-foreground">
                {(displayName || user?.name || "?")[0].toUpperCase()}
              </span>
            )}
          </div>
        </label>
        <input
          id="avatar-upload"
          type="file"
          accept="image/*"
          onChange={handleAvatarChange}
          className="hidden"
          data-testid="input-avatar"
        />
        <p className="text-xs text-muted-foreground">Tap to upload photo</p>
      </div>

      {/* Display name */}
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-medium text-foreground/70 uppercase tracking-wide">Display name</label>
        <input
          type="text"
          value={displayName || user?.name || ""}
          onChange={(e) => setDisplayName(e.target.value)}
          placeholder="Your name"
          data-testid="input-display-name"
          className="w-full h-11 px-3.5 rounded-lg bg-secondary border border-border text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
        />
      </div>

      <button
        data-testid="button-finish"
        onClick={() => handleFinish(false)}
        disabled={completeOnboarding.isPending}
        className="w-full h-11 bg-foreground text-background text-sm font-medium rounded-lg hover:bg-foreground/90 disabled:opacity-50 transition-all mt-2"
      >
        {completeOnboarding.isPending ? "Saving..." : "Get started"}
      </button>
      <button
        data-testid="button-skip"
        onClick={() => handleFinish(true)}
        disabled={completeOnboarding.isPending}
        className="w-full h-10 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        Skip for now
      </button>
    </div>,
  ];

  const progressPercent = ((step + 1) / steps.length) * 100;

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background">
      {/* Header */}
      <div className="px-5 pt-6 pb-4">
        <div className="flex items-center gap-2 mb-6">
          <Logo className="w-6 h-6 text-foreground" />
          <span className="text-sm font-medium text-foreground">Stealth</span>
        </div>
        {/* Progress */}
        <div className="w-full h-0.5 bg-secondary rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <p className="text-xs text-muted-foreground mt-2">Step {step + 1} of {steps.length}</p>
      </div>

      {/* Content */}
      <div className="flex-1 px-5 pb-8 overflow-y-auto">
        {step > 0 && (
          <button
            onClick={() => setStep((s) => s - 1)}
            className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="15 18 9 12 15 6" />
            </svg>
            Back
          </button>
        )}
        {steps[step]}
      </div>
    </div>
  );
}
