import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetProject,
  useListMessages,
  useSendMessage,
  useUpdateProject,
  useUploadFile,
  getGetProjectQueryKey,
  getListMessagesQueryKey,
  getListProjectsQueryKey,
} from "@workspace/api-client-react";
import { Sidebar } from "@/components/Sidebar";
import { ThinkingAnimation } from "@/components/ThinkingAnimation";
import { Logo } from "@/components/Logo";

const SLASH_COMMANDS = [
  { cmd: "/solve", desc: "Research and analyze any problem" },
  { cmd: "/build", desc: "Generate production-ready code" },
  { cmd: "/analyze", desc: "Deep dive into data or concepts" },
  { cmd: "/research", desc: "Comprehensive information gathering" },
];

export function Chat() {
  const params = useParams<{ projectId: string }>();
  const projectId = params.projectId;
  const [, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [input, setInput] = useState("");
  const [url, setUrl] = useState("");
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [showSlash, setShowSlash] = useState(false);
  const [isWaiting, setIsWaiting] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();

  const { data: project } = useGetProject(projectId, {
    query: { queryKey: getGetProjectQueryKey(projectId) },
  });
  const { data: messages = [], isLoading: messagesLoading } = useListMessages(projectId, {
    query: { queryKey: getListMessagesQueryKey(projectId) },
  });
  const sendMessage = useSendMessage();
  const uploadFile = useUploadFile();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isWaiting]);

  function handleInputChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    const val = e.target.value;
    setInput(val);
    setShowSlash(val.startsWith("/") && val.length <= 15);
  }

  async function handleSend() {
    const text = input.trim();
    if (!text || isWaiting) return;
    setInput("");
    setShowSlash(false);
    setIsWaiting(true);
    try {
      await sendMessage.mutateAsync({
        projectId,
        data: { content: text, attachmentUrl: url || null },
      });
      setUrl("");
      setShowUrlInput(false);
    } finally {
      setIsWaiting(false);
      queryClient.invalidateQueries({ queryKey: getListMessagesQueryKey(projectId) });
      queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });
    }
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSend();
    }
    if (e.key === "Escape") setShowSlash(false);
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    try {
      const res = await uploadFile.mutateAsync({ projectId, data: formData as any });
      setInput((prev) => prev + `\n[File: ${res.name}](${res.url})`);
    } catch {}
  }

  const urlHostname = (() => {
    try { return new URL(url).hostname; } catch { return ""; }
  })();

  return (
    <div className="flex h-[100dvh] bg-background overflow-hidden">
      {/* Sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/30" onClick={() => setSidebarOpen(false)} />
      )}
      <div className={`fixed inset-y-0 left-0 z-40 transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} md:relative md:translate-x-0 md:flex`}>
        <Sidebar currentProjectId={projectId} onClose={() => setSidebarOpen(false)} />
      </div>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <div className="flex items-center gap-2 px-4 h-12 border-b border-border shrink-0">
          <button
            onClick={() => setSidebarOpen(true)}
            className="md:hidden p-1.5 rounded-lg hover:bg-muted transition-colors"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" />
              <rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
            </svg>
          </button>
          <div className="flex items-center gap-1.5 flex-1 min-w-0">
            <span className="text-sm font-medium text-foreground truncate">
              {project?.name ?? "Loading..."}
            </span>
          </div>
          <button
            onClick={() => setLocation("/dashboard")}
            className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-5">
          {messagesLoading ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="w-5 h-5 border-2 border-muted border-t-foreground rounded-full animate-spin" />
            </div>
          ) : messages.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center gap-2 text-center opacity-50">
              <Logo className="w-8 h-8" />
              <p className="text-sm text-muted-foreground">Send a message to get started</p>
            </div>
          ) : (
            messages.map((msg) => (
              <MessageBubble key={msg.id} message={msg} />
            ))
          )}

          {isWaiting && <ThinkingAnimation />}
          <div ref={messagesEndRef} />
        </div>

        {/* Input area */}
        <div className="px-3 pb-4 shrink-0">
          {/* Slash commands */}
          {showSlash && (
            <div className="mb-2 bg-card border border-border rounded-xl overflow-hidden shadow-lg">
              {SLASH_COMMANDS.filter((c) => c.cmd.startsWith(input)).map((cmd) => (
                <button
                  key={cmd.cmd}
                  onClick={() => { setInput(cmd.cmd + " "); setShowSlash(false); }}
                  className="w-full text-left px-4 py-2.5 hover:bg-muted transition-colors"
                >
                  <span className="text-sm font-medium text-foreground">{cmd.cmd}</span>
                  <span className="text-xs text-muted-foreground ml-2">{cmd.desc}</span>
                </button>
              ))}
            </div>
          )}

          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {/* URL input */}
            {showUrlInput && (
              <div className="px-4 pt-3 pb-1">
                <div className="flex items-center gap-2 bg-muted rounded-lg px-3 py-2">
                  {urlHostname && (
                    <img
                      src={`https://www.google.com/s2/favicons?domain=${urlHostname}&sz=32`}
                      className="w-4 h-4 rounded-sm flex-shrink-0"
                      onError={(e) => (e.currentTarget.style.display = "none")}
                      alt=""
                    />
                  )}
                  <input
                    type="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://website.com"
                    data-testid="input-url"
                    className="flex-1 text-sm text-foreground bg-transparent outline-none placeholder:text-muted-foreground"
                  />
                  <button onClick={() => { setUrl(""); setShowUrlInput(false); }} className="text-muted-foreground hover:text-foreground">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                    </svg>
                  </button>
                </div>
              </div>
            )}

            <textarea
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder='Describe your project... (type "/" for commands)'
              rows={3}
              data-testid="input-message"
              disabled={isWaiting}
              className="w-full px-4 pt-3 pb-2 text-sm text-foreground placeholder:text-muted-foreground bg-transparent outline-none resize-none disabled:opacity-50"
            />

            <div className="flex items-center justify-between px-3 pb-3">
              <div className="flex items-center gap-1">
                <button
                  data-testid="button-attach"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                  title="Attach file"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
                  </svg>
                </button>
                <input ref={fileInputRef} type="file" className="hidden" onChange={handleFileUpload} data-testid="input-file" />

                <button
                  data-testid="button-url"
                  onClick={() => setShowUrlInput((v) => !v)}
                  className={`p-2 rounded-lg hover:bg-muted transition-colors ${showUrlInput ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
                  title="Add URL reference"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="2" y1="12" x2="22" y2="12" />
                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                  </svg>
                </button>
              </div>

              <button
                data-testid="button-send"
                onClick={handleSend}
                disabled={!input.trim() || isWaiting}
                className="w-8 h-8 rounded-lg bg-foreground flex items-center justify-center disabled:opacity-30 hover:bg-foreground/80 transition-all"
              >
                {isWaiting ? (
                  <div className="w-3.5 h-3.5 border-2 border-background/40 border-t-background rounded-full animate-spin" />
                ) : (
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="text-background">
                    <line x1="12" y1="19" x2="12" y2="5" />
                    <polyline points="5 12 12 5 19 12" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ message }: { message: any }) {
  const isUser = message.role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} gap-2.5`}>
      {!isUser && (
        <div className="w-7 h-7 rounded-full bg-foreground flex items-center justify-center flex-shrink-0 mt-0.5">
          <Logo className="w-4 h-4 text-background" />
        </div>
      )}
      <div className={`max-w-[85%] ${isUser ? "max-w-[75%]" : ""}`}>
        {!isUser && message.thinkingSteps?.length > 0 && (
          <div className="mb-2">
            <div className="flex flex-col gap-1">
              {message.thinkingSteps.map((step: string, i: number) => (
                <span key={i} className="text-xs text-muted-foreground/60 flex items-center gap-1">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="9 18 15 12 9 6" />
                  </svg>
                  {step}
                </span>
              ))}
            </div>
          </div>
        )}
        <div
          className={`px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
            isUser
              ? "bg-foreground text-background rounded-tr-sm"
              : "bg-muted text-foreground rounded-tl-sm"
          }`}
        >
          {message.content}
        </div>
        <p className="text-[10px] text-muted-foreground mt-1 px-1">
          {new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </p>
      </div>
    </div>
  );
}
