import { useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetMe,
  useUpdateProfile,
  useUploadAvatar,
  useLogout,
  getGetMeQueryKey,
} from "@workspace/api-client-react";
import { Sidebar } from "@/components/Sidebar";
import { Logo } from "@/components/Logo";

export function Settings() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [name, setName] = useState("");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const updateProfile = useUpdateProfile();
  const uploadAvatar = useUploadAvatar();
  const logout = useLogout();

  const displayName = name || user?.name || "";
  const avatarUrl = avatarPreview || user?.avatar;

  function handleAvatarChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setAvatarFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setAvatarPreview(reader.result as string);
    reader.readAsDataURL(file);
  }

  async function handleSave() {
    const patch: { name?: string } = {};
    if (displayName && displayName !== user?.name) patch.name = displayName;
    if (Object.keys(patch).length) {
      await updateProfile.mutateAsync({ data: patch });
    }
    if (avatarFile) {
      const formData = new FormData();
      formData.append("file", avatarFile);
      await uploadAvatar.mutateAsync({ data: formData as any });
    }
    await queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  async function handleLogout() {
    await logout.mutateAsync();
    localStorage.removeItem("token");
    queryClient.clear();
    setLocation("/");
  }

  return (
    <div className="flex h-[100dvh] bg-background overflow-hidden">
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/30" onClick={() => setSidebarOpen(false)} />
      )}
      <div className={`fixed inset-y-0 left-0 z-40 transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} md:relative md:translate-x-0 md:flex`}>
        <Sidebar currentProjectId={null} onClose={() => setSidebarOpen(false)} />
      </div>

      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex items-center gap-3 px-4 h-12 border-b border-border shrink-0">
          <button
            onClick={() => setSidebarOpen(true)}
            className="md:hidden p-1.5 rounded-lg hover:bg-muted transition-colors"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" />
              <rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
            </svg>
          </button>
          <span className="text-sm font-medium text-foreground">Settings</span>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-6 max-w-lg mx-auto w-full">
          {/* Profile */}
          <section className="mb-8">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">Profile</h2>

            {/* Avatar */}
            <div className="flex items-center gap-4 mb-5">
              <label htmlFor="avatar-settings" className="cursor-pointer">
                <div className="w-16 h-16 rounded-full border-2 border-dashed border-border overflow-hidden flex items-center justify-center bg-muted hover:border-primary/50 transition-colors">
                  {avatarUrl ? (
                    <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-xl font-bold text-muted-foreground">
                      {(user?.name || "?")[0].toUpperCase()}
                    </span>
                  )}
                </div>
              </label>
              <input id="avatar-settings" type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" data-testid="input-avatar" />
              <div>
                <p className="text-sm font-medium text-foreground">{user?.name}</p>
                <p className="text-xs text-muted-foreground">{user?.email}</p>
                <label htmlFor="avatar-settings" className="text-xs text-primary cursor-pointer hover:underline">
                  Change photo
                </label>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-medium text-foreground/70 uppercase tracking-wide">Display name</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={user?.name}
                  data-testid="input-name"
                  className="w-full h-11 px-3.5 rounded-lg bg-secondary border border-border text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                />
              </div>

              <button
                data-testid="button-save"
                onClick={handleSave}
                disabled={updateProfile.isPending || uploadAvatar.isPending}
                className="h-10 px-5 bg-foreground text-background text-sm font-medium rounded-lg hover:bg-foreground/90 disabled:opacity-50 transition-all self-start"
              >
                {saved ? "Saved" : updateProfile.isPending ? "Saving..." : "Save changes"}
              </button>
            </div>
          </section>

          {/* Info */}
          <section className="mb-8">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">Account</h2>
            <div className="bg-card border border-border rounded-xl overflow-hidden divide-y divide-border">
              {[
                { label: "Email", value: user?.email },
                { label: "Skill level", value: user?.skillLevel },
                { label: "Category", value: user?.category },
                { label: "Joined", value: user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : "" },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between px-4 py-3">
                  <span className="text-sm text-muted-foreground">{item.label}</span>
                  <span className="text-sm text-foreground font-medium capitalize">{item.value || "—"}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Sign out */}
          <section>
            <button
              data-testid="button-logout"
              onClick={handleLogout}
              className="w-full h-11 border border-destructive/30 text-destructive text-sm font-medium rounded-xl hover:bg-destructive/5 transition-colors"
            >
              Sign out
            </button>
          </section>
        </div>
      </div>
    </div>
  );
}
