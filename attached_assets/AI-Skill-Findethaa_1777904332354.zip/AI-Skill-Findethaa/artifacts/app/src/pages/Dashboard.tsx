import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetMe,
  useListProjects,
  useCreateProject,
  useGenerateProjectName,
  useDeleteProject,
  useLogout,
  getGetMeQueryKey,
  getListProjectsQueryKey,
} from "@workspace/api-client-react";
import { Sidebar } from "@/components/Sidebar";
import { Logo } from "@/components/Logo";

export function Dashboard() {
  const [description, setDescription] = useState("");
  const [url, setUrl] = useState("");
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: projects } = useListProjects({ query: { queryKey: getListProjectsQueryKey() } });
  const createProject = useCreateProject();
  const generateName = useGenerateProjectName();

  async function handleSubmit() {
    if (!description.trim()) return;

    const projectRes = await createProject.mutateAsync({
      data: { description: description.trim(), url: url || null },
    });

    // Generate a better name in background
    generateName.mutate(
      { data: { description: description.trim() } },
      {
        onSuccess: async (nameRes) => {
          // navigate, project will get name updated by chat page
          setLocation(`/chat/${projectRes.id}`);
        },
      }
    );

    setLocation(`/chat/${projectRes.id}`);
    queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSubmit();
    }
  }

  const isPending = createProject.isPending;

  return (
    <div className="flex h-[100dvh] bg-background overflow-hidden">
      {/* Sidebar overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/30"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-40 transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} md:relative md:translate-x-0 md:flex`}>
        <Sidebar currentProjectId={null} onClose={() => setSidebarOpen(false)} />
      </div>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <div className="flex items-center justify-between px-4 h-12 border-b border-border shrink-0">
          <button
            data-testid="button-toggle-sidebar"
            onClick={() => setSidebarOpen(true)}
            className="md:hidden p-1.5 rounded-lg hover:bg-muted transition-colors"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" />
              <rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
            </svg>
          </button>
          <div className="flex items-center gap-2">
            <Logo className="w-5 h-5 text-foreground hidden md:block" />
            <span className="text-sm font-medium text-foreground">New project</span>
          </div>
          <div className="w-8" />
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto flex flex-col">
          <div className="flex-1 flex flex-col items-center justify-center px-4 py-8 min-h-[50vh]">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground text-center mb-6 max-w-xs leading-tight">
              What do you want to build?
            </h1>

            {/* Input card */}
            <div className="w-full max-w-lg bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
              <textarea
                ref={textareaRef}
                data-testid="input-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Describe your project, business problem, or idea..."
                rows={4}
                className="w-full px-4 pt-4 pb-2 text-sm text-foreground placeholder:text-muted-foreground bg-transparent outline-none resize-none"
              />

              {/* URL input */}
              {showUrlInput && (
                <div className="px-4 pb-2">
                  <div className="flex items-center gap-2 bg-muted rounded-lg px-3 py-2">
                    {url && (
                      <img
                        src={`https://www.google.com/s2/favicons?domain=${(() => { try { return new URL(url).hostname; } catch { return ""; } })()}&sz=32`}
                        className="w-4 h-4 rounded-sm flex-shrink-0"
                        onError={(e) => (e.currentTarget.style.display = "none")}
                        alt=""
                      />
                    )}
                    <input
                      type="url"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      placeholder="https://reference-website.com"
                      data-testid="input-url"
                      className="flex-1 text-sm text-foreground bg-transparent outline-none placeholder:text-muted-foreground"
                    />
                    <button onClick={() => { setUrl(""); setShowUrlInput(false); }} className="text-muted-foreground hover:text-foreground ml-1">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                      </svg>
                    </button>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between px-3 pb-3">
                <div className="flex items-center gap-1">
                  <button
                    data-testid="button-attach"
                    className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                    title="Attach file"
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
                    </svg>
                  </button>
                  <button
                    data-testid="button-url"
                    onClick={() => setShowUrlInput((v) => !v)}
                    className={`p-2 rounded-lg hover:bg-muted transition-colors ${showUrlInput ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
                    title="Add URL"
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="12" cy="12" r="10" />
                      <line x1="2" y1="12" x2="22" y2="12" />
                      <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                    </svg>
                  </button>
                </div>
                <button
                  data-testid="button-send"
                  onClick={handleSubmit}
                  disabled={!description.trim() || isPending}
                  className="w-8 h-8 rounded-lg bg-foreground flex items-center justify-center disabled:opacity-30 hover:bg-foreground/80 transition-all"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="text-background">
                    <line x1="12" y1="19" x2="12" y2="5" />
                    <polyline points="5 12 12 5 19 12" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          {/* Feature cards */}
          <div className="px-4 pb-8 w-full max-w-lg mx-auto">
            <div className="flex flex-col gap-2.5">
              {[
                { tag: "Solve", color: "bg-violet-100 text-violet-700", desc: "Any question. Any situation. Every angle researched, evidence weighed — ready to act on." },
                { tag: "Build", color: "bg-orange-100 text-orange-700", desc: "Production-grade from the first generation. Output that used to require a design+dev team." },
                { tag: "Intelligence", color: "bg-pink-100 text-pink-700", desc: "Every platform your competitor is on reveals their strategy. Watch all of them." },
              ].map((card) => (
                <button
                  key={card.tag}
                  data-testid={`card-${card.tag.toLowerCase()}`}
                  onClick={() => { setDescription(card.tag + ": "); textareaRef.current?.focus(); }}
                  className="w-full text-left p-3.5 rounded-xl border border-border hover:border-foreground/30 bg-card hover:bg-muted/30 transition-all group"
                >
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-md ${card.color} mb-1.5 inline-block`}>
                    {card.tag}
                  </span>
                  <p className="text-sm text-muted-foreground leading-relaxed">{card.desc}</p>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
