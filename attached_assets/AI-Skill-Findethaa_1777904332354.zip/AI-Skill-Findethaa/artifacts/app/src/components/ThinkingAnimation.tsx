import { useState, useEffect } from "react";
import { Logo } from "./Logo";

const THINKING_STAGES = [
  { label: "Thinking...", duration: 1200 },
  { label: "Gathering information...", duration: 1500 },
  { label: "Analyzing your request...", duration: 1500 },
  { label: "Preparing response...", duration: 99999 },
];

export function ThinkingAnimation() {
  const [stageIndex, setStageIndex] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    if (stageIndex >= THINKING_STAGES.length - 1) return;
    const t = setTimeout(() => {
      setVisible(false);
      setTimeout(() => {
        setStageIndex((i) => Math.min(i + 1, THINKING_STAGES.length - 1));
        setVisible(true);
      }, 200);
    }, THINKING_STAGES[stageIndex].duration);
    return () => clearTimeout(t);
  }, [stageIndex]);

  const stage = THINKING_STAGES[stageIndex];

  return (
    <div className="flex justify-start gap-2.5">
      <div className="w-7 h-7 rounded-full bg-foreground flex items-center justify-center flex-shrink-0 mt-0.5">
        <Logo className="w-4 h-4 text-background" />
      </div>
      <div className="bg-muted rounded-2xl rounded-tl-sm px-3.5 py-2.5">
        <div
          className={`flex items-center gap-2 transition-opacity duration-200 ${visible ? "opacity-100" : "opacity-0"}`}
        >
          {/* Pulse dots */}
          <div className="flex items-center gap-0.5">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-1.5 h-1.5 rounded-full bg-foreground/25"
                style={{
                  animation: `thinking-pulse 1.2s ease-in-out ${i * 0.2}s infinite`,
                }}
              />
            ))}
          </div>
          <span className="text-sm text-muted-foreground">{stage.label}</span>
        </div>

        <style>{`
          @keyframes thinking-pulse {
            0%, 60%, 100% { opacity: 0.25; transform: scale(1); }
            30% { opacity: 1; transform: scale(1.3); }
          }
        `}</style>
      </div>
    </div>
  );
}
