export function Logo({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 32 20"
      fill="currentColor"
      className={className || "w-7 h-5"}
    >
      {/* B-2 stealth bomber silhouette - flat flying wing shape */}
      <path d="M16 0 L32 14 L27 16 L22 13 L16 20 L10 13 L5 16 L0 14 Z" />
    </svg>
  );
}
