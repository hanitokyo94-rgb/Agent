import { useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetMe,
  useListProjects,
  useDeleteProject,
  useLogout,
  getGetMeQueryKey,
  getListProjectsQueryKey,
} from "@workspace/api-client-react";
import { Logo } from "./Logo";
import { Drawer, DrawerContent, DrawerTrigger } from "@/components/ui/drawer";

interface SidebarProps {
  currentProjectId: string | null;
  onClose?: () => void;
}

export function Sidebar({ currentProjectId, onClose }: SidebarProps) {
  const [, setLocation] = useLocation();
  const [profileOpen, setProfileOpen] = useState(false);
  const [menuProjectId, setMenuProjectId] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: projects = [] } = useListProjects({ query: { queryKey: getListProjectsQueryKey() } });
  const deleteProject = useDeleteProject();
  const logout = useLogout();

  function navigate(path: string) {
    setLocation(path);
    onClose?.();
  }

  async function handleLogout() {
    await logout.mutateAsync();
    localStorage.removeItem("token");
    queryClient.clear();
    setLocation("/");
  }

  async function handleDelete(projectId: string) {
    await deleteProject.mutateAsync({ projectId });
    queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });
    setMenuProjectId(null);
    if (currentProjectId === projectId) {
      setLocation("/dashboard");
    }
    onClose?.();
  }

  const avatarUrl = user?.avatar;
  const initials = (user?.name || "?")[0].toUpperCase();

  return (
    <div className="w-64 h-full bg-sidebar border-r border-sidebar-border flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-2.5 px-3 h-12 border-b border-sidebar-border shrink-0">
        <button
          data-testid="nav-new-project"
          onClick={() => navigate("/dashboard")}
          className="flex items-center gap-2 flex-1 min-w-0 hover:opacity-80 transition-opacity"
        >
          <Logo className="w-6 h-6 text-sidebar-foreground flex-shrink-0" />
          <span className="text-sm font-semibold text-sidebar-foreground truncate">Stealth</span>
        </button>
        <button
          onClick={() => navigate("/dashboard")}
          className="p-1.5 rounded-lg hover:bg-sidebar-accent transition-colors text-sidebar-foreground/60 hover:text-sidebar-foreground flex-shrink-0"
          title="New project"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
          </svg>
        </button>
      </div>

      {/* Projects list */}
      <div className="flex-1 overflow-y-auto py-2">
        {projects.length === 0 ? (
          <p className="px-3 py-4 text-xs text-sidebar-foreground/40 text-center">No projects yet</p>
        ) : (
          <>
            <p className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-sidebar-foreground/40">
              Recent
            </p>
            {projects.map((project) => (
              <div key={project.id} className="relative group">
                <button
                  data-testid={`project-item-${project.id}`}
                  onClick={() => navigate(`/chat/${project.id}`)}
                  className={`w-full text-left px-3 py-2 flex items-center gap-2.5 transition-colors ${
                    currentProjectId === project.id
                      ? "bg-sidebar-accent text-sidebar-foreground"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                  }`}
                >
                  {/* Icon */}
                  <div className="w-6 h-6 rounded-md bg-muted/60 flex items-center justify-center flex-shrink-0 text-[10px] font-bold text-foreground/60">
                    {project.name?.[0]?.toUpperCase() || "P"}
                  </div>
                  <span className="text-xs font-medium truncate flex-1">{project.name}</span>
                  {project.messageCount > 0 && (
                    <span className="text-[10px] text-sidebar-foreground/40 flex-shrink-0">{project.messageCount}</span>
                  )}
                </button>

                {/* Context menu button */}
                <button
                  data-testid={`project-menu-${project.id}`}
                  onClick={(e) => { e.stopPropagation(); setMenuProjectId(menuProjectId === project.id ? null : project.id); }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-md hover:bg-muted opacity-0 group-hover:opacity-100 transition-all"
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
                    <circle cx="12" cy="5" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="12" cy="19" r="1.5" />
                  </svg>
                </button>

                {/* Project context menu */}
                {menuProjectId === project.id && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setMenuProjectId(null)} />
                    <div className="absolute right-2 top-full z-20 mt-0.5 bg-popover border border-border rounded-xl shadow-lg overflow-hidden w-40">
                      <button
                        onClick={() => handleDelete(project.id)}
                        className="w-full text-left px-3 py-2.5 text-sm text-destructive hover:bg-muted transition-colors"
                      >
                        Delete
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </>
        )}
      </div>

      {/* User profile - bottom */}
      <div className="border-t border-sidebar-border shrink-0">
        <Drawer open={profileOpen} onOpenChange={setProfileOpen}>
          <DrawerTrigger asChild>
            <button
              data-testid="button-user-menu"
              className="w-full flex items-center gap-2.5 px-3 py-3 hover:bg-sidebar-accent transition-colors"
            >
              <div className="w-7 h-7 rounded-full bg-muted overflow-hidden flex items-center justify-center flex-shrink-0">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-xs font-bold text-foreground/60">{initials}</span>
                )}
              </div>
              <span className="text-xs font-medium text-sidebar-foreground truncate flex-1 text-left">{user?.name}</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-sidebar-foreground/40 flex-shrink-0">
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </button>
          </DrawerTrigger>
          <DrawerContent className="px-0 pb-0">
            {/* User info */}
            <div className="flex items-center gap-3 px-4 py-4 border-b border-border">
              <div className="w-10 h-10 rounded-full bg-muted overflow-hidden flex items-center justify-center">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-sm font-bold text-foreground/60">{initials}</span>
                )}
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">{user?.name}</p>
                <p className="text-xs text-muted-foreground">{user?.email}</p>
              </div>
            </div>

            {/* Menu items */}
            <div className="py-1">
              <button
                data-testid="menu-settings"
                onClick={() => { setProfileOpen(false); navigate("/settings"); }}
                className="w-full flex items-center gap-3 px-4 py-3.5 text-sm text-foreground hover:bg-muted transition-colors"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="3" />
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                </svg>
                Settings
              </button>
              <button
                data-testid="menu-logout"
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3.5 text-sm text-destructive hover:bg-muted transition-colors"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                  <polyline points="16 17 21 12 16 7" />
                  <line x1="21" y1="12" x2="9" y2="12" />
                </svg>
                Sign out
              </button>
            </div>
            <div className="h-6" />
          </DrawerContent>
        </Drawer>
      </div>
    </div>
  );
}
