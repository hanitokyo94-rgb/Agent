import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { findWhere, insertRecord, findById, updateRecord } from "../lib/storage.js";

const router = Router();

interface Message {
  id: string;
  projectId: string;
  role: "user" | "assistant";
  content: string;
  thinkingSteps: string[] | null;
  createdAt: string;
}

interface Project {
  id: string;
  userId: string;
  updatedAt: string;
}

function getUserId(req: any): string | null {
  let userId = req.session?.userId;
  if (!userId) {
    const authHeader = req.headers.authorization;
    if (authHeader?.startsWith("Bearer ")) {
      const token = authHeader.slice(7);
      try {
        const decoded = Buffer.from(token, "base64").toString("utf-8");
        userId = decoded.split(":")[0];
      } catch {
        return null;
      }
    }
  }
  return userId ?? null;
}

router.get("/projects/:projectId/messages", (req, res) => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Not authenticated" }); return; }
  const project = findById<Project>("projects", req.params.projectId);
  if (!project || project.userId !== userId) {
    res.status(404).json({ error: "Project not found" });
    return;
  }
  const messages = findWhere<Message>("messages", (m) => m.projectId === req.params.projectId);
  messages.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  res.json(messages);
});

router.post("/projects/:projectId/messages", async (req, res) => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Not authenticated" }); return; }
  const project = findById<Project>("projects", req.params.projectId);
  if (!project || project.userId !== userId) {
    res.status(404).json({ error: "Project not found" });
    return;
  }
  const { content, attachmentUrl } = req.body as { content?: string; attachmentUrl?: string | null };
  if (!content) { res.status(400).json({ error: "content is required" }); return; }

  const userMsg: Message = {
    id: uuidv4(),
    projectId: req.params.projectId,
    role: "user",
    content,
    thinkingSteps: null,
    createdAt: new Date().toISOString(),
  };
  insertRecord("messages", userMsg);

  const allMessages = findWhere<Message>("messages", (m) => m.projectId === req.params.projectId);
  allMessages.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  const thinkingSteps: string[] = [];

  try {
    const OpenAI = (await import("openai")).default;
    const client = new OpenAI({
      apiKey: process.env.AI_API_KEY,
      baseURL: process.env.AI_BASE_URL,
    });

    thinkingSteps.push("Analyzing your request...");
    thinkingSteps.push("Gathering relevant information...");
    thinkingSteps.push("Preparing a detailed response...");

    const history = allMessages.slice(-10).map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    }));

    const completion = await client.chat.completions.create({
      model: process.env.AI_MODEL ?? "anthropic/claude-opus-4-6",
      messages: [
        {
          role: "system",
          content: `You are an expert AI assistant that helps users build projects, solve problems, and make decisions. Be concise, practical, and insightful. When analyzing business/tech projects, provide actionable guidance.`,
        },
        ...history,
      ],
      max_tokens: 2000,
    });

    const aiContent = completion.choices[0]?.message?.content ?? "I couldn't generate a response. Please try again.";

    const aiMsg: Message = {
      id: uuidv4(),
      projectId: req.params.projectId,
      role: "assistant",
      content: aiContent,
      thinkingSteps,
      createdAt: new Date().toISOString(),
    };
    insertRecord("messages", aiMsg);

    updateRecord<Project>("projects", req.params.projectId, { updatedAt: new Date().toISOString() });

    res.json(aiMsg);
  } catch (err: any) {
    req.log?.error({ err }, "AI response failed");
    const errMsg: Message = {
      id: uuidv4(),
      projectId: req.params.projectId,
      role: "assistant",
      content: "I encountered an error processing your request. Please check the AI configuration and try again.",
      thinkingSteps,
      createdAt: new Date().toISOString(),
    };
    insertRecord("messages", errMsg);
    res.json(errMsg);
  }
});

router.post("/ai/chat", async (req, res) => {
  const { messages } = req.body as {
    messages?: Array<{ role: "user" | "assistant"; content: string }>;
  };
  if (!messages?.length) { res.status(400).json({ error: "messages are required" }); return; }

  const thinkingSteps: string[] = [
    "Processing your request...",
    "Formulating response...",
  ];

  try {
    const OpenAI = (await import("openai")).default;
    const client = new OpenAI({
      apiKey: process.env.AI_API_KEY,
      baseURL: process.env.AI_BASE_URL,
    });

    const completion = await client.chat.completions.create({
      model: process.env.AI_MODEL ?? "anthropic/claude-opus-4-6",
      messages: [
        {
          role: "system",
          content: "You are a helpful AI assistant. Be concise and useful.",
        },
        ...messages,
      ],
      max_tokens: 2000,
    });

    const content = completion.choices[0]?.message?.content ?? "No response generated.";
    res.json({ content, thinkingSteps });
  } catch (err) {
    req.log?.error({ err }, "AI chat failed");
    res.status(500).json({ error: "AI service unavailable" });
  }
});

export default router;
